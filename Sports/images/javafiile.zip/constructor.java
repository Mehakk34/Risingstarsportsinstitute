class constructorover {
    int a;
    double b;
    String c;

    constructorover(){
        a=34; b=45.67; c="Shinchan";
    }

    constructorover(int A) {
        a = A;
    }

    constructorover(double B, String C){
        b=B;c=C;

    }
}

public class constructor {
    public static void main(String args[]) {
        constructorover S1 = new constructorover();
        constructorover S2 = new constructorover(56);
        constructorover S3 = new constructorover(78.9, "Komal");
        System.out.println("a=" + S1.a+"  b=" + S1.b+"  c=" + S1.c);
        System.out.println("a=" + S2.a);
        System.out.println("b=" + S3.b+"  c=" + S3.c);


    }
}
