public class pattren8{
public static void main(String[] args){

    int r,c;
    for(r=5; r>=1; r--){
       for(c=1; c<=r; c++){
          System.out.print("*");
       }
       System.out.print("\n");  
    }   
}
}