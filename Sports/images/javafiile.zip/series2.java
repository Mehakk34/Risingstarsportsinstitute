import java.util.Scanner;

public class series2{
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the m");
        int m=scanner.nextInt();
        scanner.close();
        int sum=0;
        int c=0;
        for(int i=1; i<=m; i++){ 
            c=(c*10)+1;
            System.out.println(c+  "\t");
            sum+=c;      
        }
        System.out.println(sum);         
    }
}