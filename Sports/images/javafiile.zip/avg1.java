import java.util.Scanner;

public class avg1{
    public static void main(String[] args){
        int a,b,avg;
        Scanner scanner= new Scanner(System.in);
        System.out.println("Enter the a");
        a=scanner.nextInt();
        System.out.println("Enter the b");
        b=scanner.nextInt();
        avg=(a+b)/2;
        System.out.println("avg="+avg);
    }
}
