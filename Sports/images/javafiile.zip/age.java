import java.util.Scanner;

public class age {
     public static void main(String[] args){
    System.out.println("Enter the int");
    Scanner scanner= new Scanner(System.in);
    int sn=scanner.nextInt();
    if(sn>=18){
        System.out.println("The person can vote");
    }
    else
    {
        System.out.println("The person can't vote");
    }
    }  
}
