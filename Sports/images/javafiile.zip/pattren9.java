public class pattren9{
public static void main(String[] args){

    int r,c,p=5;
    for(r=1; r<=5; r++){
       for(c=1; c<=p; c++){
          System.out.print(" ");
       }
       p=p-1;
       for(c=1; c<=r; c++){
          System.out.print(c);
       }
       for(c=r-1; c>=1; c--){
          System.out.print(c);
       }
       
       System.out.print("\n");  
    }
}
}