class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}

//different calculation in java
class addition {
    public static void main(String[] args){
        int a,b,c;
        a=10;
        b=12;
        c=a+b;
        System.out.println("c");
    }
}
