public class pattren12{
public static void main(String[] args){

    int r,c;
    for(r=1; r<=7; r++){
        
        for(c=1; c<=7-r; c++){
            System.out.print(" ");

        }
        for(c=1;c<=r;c++){
            System.out.print(r+" ");
        } 
        System.out.println();  
    }
        
}
}
