import java.util.Scanner;

public class Reverse{
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the m");
        int m=scanner.nextInt();
        scanner.close();
    
        int reverse = 0;
        for(int i=m; i>0; i/=10)
           reverse=reverse*10+i%10;
           
        System.out.print("Reverse:" + reverse);
        
         
    }
}