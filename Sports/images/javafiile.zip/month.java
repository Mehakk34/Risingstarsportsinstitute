import java. util.Scanner;
public class month{
    public static void main(String[] args){
    System.out.println("Enter the Month");
    Scanner scanner= new Scanner(System.in);
    String a=scanner.nextLine();
    switch(a){
        case "January":
        System.out.println("1st month of the year");
        break;
        case "Febraury":
        System.out.println("2nd month of the year");
        break;
        case "March":
        System.out.println("3th month of the year");
        break;
        case "April":
        System.out.println("4th month of the year");
        break;
        case "May":
        System.out.println("5th month of the year");
        break;
        case "June":
        System.out.println("6th month of the year");
        break;
        case "July":
        System.out.println("7th month of the year");
        break;
        case "August":
        System.out.println("8th month of the year");
        break;
        case "September":
        System.out.println("9th month of the year");
        break;
        case "October":
        System.out.println("10th month of the year");
        break;
        case "November":
        System.out.println("11th month of the year");
        break;
        case "December":
        System.out.println("12th month of the year");
        break;
    }
    }
}










