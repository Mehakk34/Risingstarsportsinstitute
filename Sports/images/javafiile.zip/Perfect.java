import java.util.Scanner;

public class Perfect{
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the n");
        int m=scanner.nextInt();
        scanner.close();
        for(int n=1; n<=m; n++){
        int sum=0;
        for(int i=1; i<=n/2; i++)*args
            if(n%i==0)
               sum +=i; 
        if(sum==n)
        System.out.println(n);
        
        
    }
    }
}