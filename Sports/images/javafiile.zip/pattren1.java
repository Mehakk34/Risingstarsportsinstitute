public class pattren1{
public static void main(String[] args){

    int r,c;
    for(r=1; r<=3; r++){
       for(c=1; c<=7; c=c+2)
       System.out.print( c);
       System.out.println("\t");
    }
    
}
}