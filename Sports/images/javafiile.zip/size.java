import java. util.Scanner;
public class size{
    public static void main(String[] args){
    System.out.println("Enter the size");
    Scanner scanner= new Scanner(System.in);
    int a=scanner.nextInt();
    switch(a){
        case 26:
        System.out.println("Size is XS");
        break;

        case 28:
        System.out.println("Size is S");
        break;

        case 30:
        System.out.println("Size is M");
        break;

        case 32:
        System.out.println("Size is L");
        break;

        case 34:
        System.out.println("Size is XL");
        break;

        case 36:
        System.out.println("Size is XXL");
        break;

        case 38:
        System.out.println("Size is XXXL");
        break;

        default:
        System.out.println("Enter the valid size");
    }
    }
}   