import java.util.Scanner;

public class calculation1 {
    public static int add(int a,int b){
        return a+b;
    }
    public static int sub(int a,int b){
        return a-b;
    }
    public static int mul(int a,int b){
        return a*b;
    }
     public static int divi(int a,int b){
        return a%b;
    }
    public static void main(String[] args){
        int a,b,c;
        Scanner scanner= new Scanner(System.in);
        System.out.println("Enter the a");
        a=scanner.nextInt();
        System.out.println("Enter the b");
        b=scanner.nextInt();
        c=add(a, b);
        System.out.println("c="+c);

        c=sub(a, b);
        System.out.println("c="+c);

         c=mul(a, b);
        System.out.println("c="+c);

         c=divi(a, b);
        System.out.println("c="+c);

    }
}