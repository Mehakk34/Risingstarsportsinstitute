import java.util.Scanner;

public class cube{
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the m");
        int m=scanner.nextInt();
        scanner.close();
    
        for(int i=1; i<=m; i++){
            
            int product=i*i*i;  
            System.out.println(product);      
        }
         
    }
}