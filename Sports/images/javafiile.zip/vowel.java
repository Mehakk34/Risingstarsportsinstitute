import java. util.Scanner;
public class vowel {
    public static void main(String[] args){
    System.out.println("Enter the ch");
    Scanner scanner= new Scanner(System.in);
    char sn=scanner.next().charAt(0);
    if(sn=='a'||sn=='u'||sn=='i'||sn=='o'||sn=='e'){
        System.out.println("The alphabet is vowel");
    }
    else
    {
        System.out.println("the alphabet is consonent");
    }
    }
}
    
   
