import java. util.Scanner;

public class Loop {
    public static void main(String[] args){
    System.out.println("Enter the n");
    Scanner scanner= new Scanner(System.in);
    int n=scanner.nextInt();
    scanner.close();
    for(int i=1; i<=n; i++)
       System.out.println(i);

    }
}