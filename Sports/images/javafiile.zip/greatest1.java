import java. util.Scanner;
public class greatest1 {
    public static void main(String[] args){
    System.out.println("Enter the a");
    Scanner scanner= new Scanner(System.in);
    int a=scanner.nextInt();
    System.out.println("Enter the b");
    int b=scanner.nextInt();
    System.out.println("Enter the c");
    int c=scanner.nextInt();
    
    if(a>b&&a>=c){
        System.out.println(a+"is the greatest number");
    }
    else if(b>=a&&b>=c)
    {
        System.out.println(b+"is the greatest number");
    }
     else
        System.out.println(c+"is the greatest number");
    }
}
    