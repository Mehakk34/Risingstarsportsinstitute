import java.util.Scanner;

public class series{
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the m");
        int m=scanner.nextInt();
        scanner.close();
        double sum=0;
        for(int i=1; i<=m; i++){
        int product=1;
           for(int p=1; p<=i; p++)
              product *= i; 
            //   System.out.println(1.0/product);
            sum+=(1.0 / product);
        }   
        System.out.println(sum); 
    }
}