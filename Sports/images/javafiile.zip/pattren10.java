public class pattren10{
public static void main(String[] args){

    int r,c;
    for(r=1; r<=7; r++){
       for(c=1; c<=7; c++)
       System.out.print( "*");
       System.out.println("\t");
    }
    
}
}