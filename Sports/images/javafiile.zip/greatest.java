public class greatest {
    public static void main(String[] args){
        int a=6,b=8,c=4;
        if(a>=b&&a>=c)
        System.out.println(a+ "is the greatest number");
        else if(b>=a&&b>=c)
        System.out.println(b+"is the greatext number");
        else
        System.out.println(c+"is the greatext number");
    }   
}
