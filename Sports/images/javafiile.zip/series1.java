import java.util.Scanner;

public class series1{
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the m");
        int m=scanner.nextInt();
        scanner.close();
        int sum=0;
        for(int i=1; i<=m; i++){ 
            sum+=i*i;        
        }
        System.out.println(sum); 
    }
}