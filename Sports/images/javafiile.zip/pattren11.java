public class pattren11{
public static void main(String[] args){

    int r,c;
    for(r=1; r<=7; r++){
        
        for(c=1; c<=7; c++){
           if(r==1||c==1||r==7||c==7){
           System.out.print( "* ");
           
           }
           else
           System.out.print("  ");
           
        }
        System.out.println();
}
}
}