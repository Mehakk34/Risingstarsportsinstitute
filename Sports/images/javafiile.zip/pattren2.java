public class pattren2{
public static void main(String[] args){

    int r;
    
    for(r=0; r<=4; r++){
       for( char c='a'; c<='e'; c++){
       System.out.print( c);
    }
    System.out.println("\t");        
       
    }
}
}


























