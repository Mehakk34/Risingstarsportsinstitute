import java.util.Scanner;

public class sumseries{
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the m");
        int m=scanner.nextInt();
        scanner.close();
        int Totalsum=0;
        for(int i=1; i<=m; i++){
            int sum=0;
            for(int n=1; n<=i; n++)
                sum+=n; 
            Totalsum+=(sum);

        }
        System.out.println(Totalsum); 
    }
}