import java.util.Scanner;

// Shape class (base class)
class Shape {
    public double calculateArea() {
        return 0.0;  // Default implementation for area calculation
    }
}

// Circle class (inherits from Shape)
class Circle extends Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

   
    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}

// Triangle class (inherits from Shape)
class Triangle extends Shape {
    private double base;
    private double height;

    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    @Override
    public double calculateArea() {
        return 0.5 * base * height;
    }
}

// EquilateralTriangle class (inherits from Triangle)
class EquilateralTriangle extends Triangle {
    public EquilateralTriangle(double sideLength) {
        super(sideLength, (Math.sqrt(3) / 2) * sideLength);
    }
}

public class inheritance{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Circle
        System.out.print("Enter the radius of the circle: ");
        double radius = scanner.nextDouble();
        Circle circle = new Circle(radius);
        System.out.println("Area of the circle: " + circle.calculateArea());

        // Triangle
        System.out.print("Enter the base length of the triangle: ");
        double base = scanner.nextDouble();
        System.out.print("Enter the height of the triangle: ");
        double height = scanner.nextDouble();
        Triangle triangle = new Triangle(base, height);
        System.out.println("Area of the triangle: " + triangle.calculateArea());

        // Equilateral Triangle
        System.out.print("Enter the side length of the equilateral triangle: ");
        double sideLength = scanner.nextDouble();
        EquilateralTriangle equilateralTriangle = new EquilateralTriangle(sideLength);
        System.out.println("Area of the equilateral triangle: " + equilateralTriangle.calculateArea());

        scanner.close();
    }
}