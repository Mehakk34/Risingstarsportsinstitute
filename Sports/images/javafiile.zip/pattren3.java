
public class pattren3{
public static void main(String[] args){
    
    for( char r='a'; r<='e'; r++){
       for( int c=1; c<=5; c++){
       System.out.print( r);
    }
    System.out.println("\t");        
       
    }
}
}