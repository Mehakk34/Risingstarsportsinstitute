public class linearsearch {
    public static int linears(int arr[], int key) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String args[]) {
        int[] a1 = {56, 78, 34, 65, 87, 98, 67};
        int key = 65;
        System.out.println(key + " is found at index " + linears(a1, key));
    }
}
