import java. util.Scanner;

public class Loopavg {
    public static void main(String[] args){
    System.out.println("Enter the n");
    Scanner scanner= new Scanner(System.in);
    int n=scanner.nextInt();
    scanner.close();
    int sum=0;
    for(int i=1; i<=n; i++)
    sum+=i;
    System.out.println("sum of first" +n+ "is" +sum);
    double avg= (double) sum / (double) n;
    System.out.println("The avg of n numbers are"+avg);
    }
}
