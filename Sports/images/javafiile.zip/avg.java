public class avg {
    public static void main(String[] args){
        int a,b,avg;
        a=10;
        b=12;
        avg=(a+b)/2;
        System.out.println("avg="+avg);
    }
}
